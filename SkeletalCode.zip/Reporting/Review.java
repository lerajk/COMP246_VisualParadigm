package Reporting;

public class Review {

	private int reviewId;
	private int authorId;
	private int replyUserId;
	private int creationDate;
	private int replyDate;
	private int classification;
	private int comment;

	public void createReview() {
		// TODO - implement Review.createReview
		throw new UnsupportedOperationException();
	}

	public void replyReview() {
		// TODO - implement Review.replyReview
		throw new UnsupportedOperationException();
	}

}