package Reporting;

public class ReportingController {

	public void addReview() {
		// TODO - implement ReportingController.addReview
		throw new UnsupportedOperationException();
	}

	public void replyReview() {
		// TODO - implement ReportingController.replyReview
		throw new UnsupportedOperationException();
	}

}