public class View {

	public void login() {
		// TODO - implement View.login
		throw new UnsupportedOperationException();
	}

	public void registerUser() {
		// TODO - implement View.registerUser
		throw new UnsupportedOperationException();
	}

	public void removeUser() {
		// TODO - implement View.removeUser
		throw new UnsupportedOperationException();
	}

	public void changeAdminRole() {
		// TODO - implement View.changeAdminRole
		throw new UnsupportedOperationException();
	}

	public void changePassword() {
		// TODO - implement View.changePassword
		throw new UnsupportedOperationException();
	}

	public void addReview() {
		// TODO - implement View.addReview
		throw new UnsupportedOperationException();
	}

	public void replyReview() {
		// TODO - implement View.replyReview
		throw new UnsupportedOperationException();
	}

	public void searchProduct() {
		// TODO - implement View.searchProduct
		throw new UnsupportedOperationException();
	}

	public void addShoppingListItem() {
		// TODO - implement View.addShoppingListItem
		throw new UnsupportedOperationException();
	}

	public void removeShoppingListItem() {
		// TODO - implement View.removeShoppingListItem
		throw new UnsupportedOperationException();
	}

	public void sortShoppingList() {
		// TODO - implement View.sortShoppingList
		throw new UnsupportedOperationException();
	}

	public void clearShoppingList() {
		// TODO - implement View.clearShoppingList
		throw new UnsupportedOperationException();
	}

	public void addSaleItem() {
		// TODO - implement View.addSaleItem
		throw new UnsupportedOperationException();
	}

	public void removeSaleItem() {
		// TODO - implement View.removeSaleItem
		throw new UnsupportedOperationException();
	}

	public void cancelSale() {
		// TODO - implement View.cancelSale
		throw new UnsupportedOperationException();
	}

	public void searchCategory() {
		// TODO - implement View.searchCategory
		throw new UnsupportedOperationException();
	}

}