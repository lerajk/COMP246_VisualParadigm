public class User {

	private int username;
	private int password;
	private int fullName;
	private int emailAddress;
	private int registrationDate;

	public void createUser() {
		// TODO - implement User.createUser
		throw new UnsupportedOperationException();
	}

	public void changePassword() {
		// TODO - implement User.changePassword
		throw new UnsupportedOperationException();
	}

	public void deleteUser() {
		// TODO - implement User.deleteUser
		throw new UnsupportedOperationException();
	}

}