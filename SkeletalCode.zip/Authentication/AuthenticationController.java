package Authentication;

public class AuthenticationController {

	public void login() {
		// TODO - implement AuthenticationController.login
		throw new UnsupportedOperationException();
	}

	public void registerUser() {
		// TODO - implement AuthenticationController.registerUser
		throw new UnsupportedOperationException();
	}

	public void removeUser() {
		// TODO - implement AuthenticationController.removeUser
		throw new UnsupportedOperationException();
	}

	public void changeAdminRole() {
		// TODO - implement AuthenticationController.changeAdminRole
		throw new UnsupportedOperationException();
	}

	public void changePassword() {
		// TODO - implement AuthenticationController.changePassword
		throw new UnsupportedOperationException();
	}

}