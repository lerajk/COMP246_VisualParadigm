public class Customer extends User {

	private int shoppingLists;
	private int reviews;

	public void createShoppingList() {
		// TODO - implement Customer.createShoppingList
		throw new UnsupportedOperationException();
	}

	public void addReview() {
		// TODO - implement Customer.addReview
		throw new UnsupportedOperationException();
	}

}