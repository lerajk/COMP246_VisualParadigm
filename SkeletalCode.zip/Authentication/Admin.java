public class Admin extends User {

	private int adminRole;

	public void changeCustomerPassword() {
		// TODO - implement Admin.changeCustomerPassword
		throw new UnsupportedOperationException();
	}

	public void removeCustomerUser() {
		// TODO - implement Admin.removeCustomerUser
		throw new UnsupportedOperationException();
	}

	public void listUsers() {
		// TODO - implement Admin.listUsers
		throw new UnsupportedOperationException();
	}

	public void listUserReviews() {
		// TODO - implement Admin.listUserReviews
		throw new UnsupportedOperationException();
	}

}