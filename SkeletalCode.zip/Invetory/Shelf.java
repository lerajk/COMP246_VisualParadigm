public class Shelf {

	private int shelfNumber;
	private int categories;
	private int aisleNumber;

	public void addCategory() {
		// TODO - implement Shelf.addCategory
		throw new UnsupportedOperationException();
	}

	public void removeCategory() {
		// TODO - implement Shelf.removeCategory
		throw new UnsupportedOperationException();
	}

}