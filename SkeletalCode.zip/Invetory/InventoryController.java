package Invetory;

public class InventoryController {

	public void searchProduct() {
		// TODO - implement InventoryController.searchProduct
		throw new UnsupportedOperationException();
	}

	public void addShoppingListItem() {
		// TODO - implement InventoryController.addShoppingListItem
		throw new UnsupportedOperationException();
	}

	public void removeShoppingListItem() {
		// TODO - implement InventoryController.removeShoppingListItem
		throw new UnsupportedOperationException();
	}

	public void sortShoppingList() {
		// TODO - implement InventoryController.sortShoppingList
		throw new UnsupportedOperationException();
	}

	public void clearShoppingList() {
		// TODO - implement InventoryController.clearShoppingList
		throw new UnsupportedOperationException();
	}

	public void addSaleItem() {
		// TODO - implement InventoryController.addSaleItem
		throw new UnsupportedOperationException();
	}

	public void removeSaleItem() {
		// TODO - implement InventoryController.removeSaleItem
		throw new UnsupportedOperationException();
	}

	public void cancelSale() {
		// TODO - implement InventoryController.cancelSale
		throw new UnsupportedOperationException();
	}

	public void searchCategory() {
		// TODO - implement InventoryController.searchCategory
		throw new UnsupportedOperationException();
	}

}