public class Product {

	private int productId;
	private int Name;
	private int categoryId;

	public void createProduct() {
		// TODO - implement Product.createProduct
		throw new UnsupportedOperationException();
	}

	public void listProducts() {
		// TODO - implement Product.listProducts
		throw new UnsupportedOperationException();
	}

	public void searchProduct() {
		// TODO - implement Product.searchProduct
		throw new UnsupportedOperationException();
	}

}