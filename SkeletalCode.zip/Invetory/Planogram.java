public class Planogram {

	private int planogramId;
	private int creationDate;
	private int lastUpdateDate;

	public void addAisle() {
		// TODO - implement Planogram.addAisle
		throw new UnsupportedOperationException();
	}

	public void moveCategory() {
		// TODO - implement Planogram.moveCategory
		throw new UnsupportedOperationException();
	}

	public void removeAisle() {
		// TODO - implement Planogram.removeAisle
		throw new UnsupportedOperationException();
	}

}