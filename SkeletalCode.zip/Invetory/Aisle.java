public class Aisle {

	private int aisleNumber;

	public void createAisle() {
		// TODO - implement Aisle.createAisle
		throw new UnsupportedOperationException();
	}

	public void deleteAisle() {
		// TODO - implement Aisle.deleteAisle
		throw new UnsupportedOperationException();
	}

}