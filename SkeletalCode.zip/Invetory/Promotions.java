public class Promotions {

	private int PromotionId;
	private int startDate;
	private int endDate;
	private int saleItems;
	private int state;

	public void addSaleItem() {
		// TODO - implement Promotions.addSaleItem
		throw new UnsupportedOperationException();
	}

	public void removeSaleItem() {
		// TODO - implement Promotions.removeSaleItem
		throw new UnsupportedOperationException();
	}

	public void cancelSale() {
		// TODO - implement Promotions.cancelSale
		throw new UnsupportedOperationException();
	}

}