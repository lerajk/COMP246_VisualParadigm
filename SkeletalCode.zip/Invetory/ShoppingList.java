public class ShoppingList {

	private int shoppingListId;
	private int creationDate;
	private int items;
	private int state;

	public void addItem() {
		// TODO - implement ShoppingList.addItem
		throw new UnsupportedOperationException();
	}

	public void removeItem() {
		// TODO - implement ShoppingList.removeItem
		throw new UnsupportedOperationException();
	}

	public void clear() {
		// TODO - implement ShoppingList.clear
		throw new UnsupportedOperationException();
	}

	public void sort() {
		// TODO - implement ShoppingList.sort
		throw new UnsupportedOperationException();
	}

}