public class Category {

	private int categoryId;
	private int name;
	private int shelfNumber;

	public void getProductList() {
		// TODO - implement Category.getProductList
		throw new UnsupportedOperationException();
	}

	public void createCategory() {
		// TODO - implement Category.createCategory
		throw new UnsupportedOperationException();
	}

	public void selectCategory() {
		// TODO - implement Category.selectCategory
		throw new UnsupportedOperationException();
	}

}